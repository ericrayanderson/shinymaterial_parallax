# [shinymaterial](https://ericrayanderson.github.io/shinymaterial/)

## R package: Implements Material Design in Shiny Applications

Install CRAN version: `install.packages("shinymaterial")`

Install Development version: `devtools::install_github("ericrayanderson/shinymaterial")`
