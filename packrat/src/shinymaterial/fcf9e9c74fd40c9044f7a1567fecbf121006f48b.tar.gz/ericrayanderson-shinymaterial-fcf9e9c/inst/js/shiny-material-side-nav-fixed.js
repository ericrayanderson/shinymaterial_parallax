   $(document).ready(function () {
       $('.nav-wrapper').prepend('<a href="#" data-activates="slide-out" class="button-collapse"><i class="material-icons">menu</i></a>');
       $(".button-collapse").sideNav();
   })
