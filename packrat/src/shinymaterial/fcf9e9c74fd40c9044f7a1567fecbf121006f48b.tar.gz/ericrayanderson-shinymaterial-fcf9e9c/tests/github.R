# library(shinymaterial)
# 
# ui <- material_page(
#   
# )
# server <- function(input, output) {
#   
# }
# shinyApp(ui = ui, server = server)